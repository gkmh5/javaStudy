package com.kh.f_poly.run;

import com.kh.f_poly.view.LibraryMenu;

public class Run {

	public static void main(String[] args) {
		// LibraryMenu 객체를 생성하여 mainMenu() 호출
		new LibraryMenu().mainMenu();
	}

}
