package com.kh.e_object_array.student.run;

import com.kh.e_object_array.student.view.StudentMenu;

public class Run {

	public static void main(String[] args) {

		StudentMenu sm = new StudentMenu();
		
	}

}
